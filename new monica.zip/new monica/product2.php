
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<title>Site Title</title>
<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//wordpress.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Site Title &raquo; Feed" href="https://monikamobiles.wordpress.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Site Title &raquo; Comments Feed" href="https://monikamobiles.wordpress.com/comments/feed/" />
	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
			<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/wpcom-smileys\/twemoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/wpcom-smileys\/twemoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/s0.wp.com\/wp-includes\/js\/wp-emoji-release.min.js?m=1612197847h&ver=5.7-beta3-50403"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='all-css-0-1' href='https://s0.wp.com/_static/??-eJylkttOwzAMhl+IJG3ZkLhAPEtOtN5yUuKs9O1xu1GhbqomcRPFh++3Y0eMiekY0AYUvrLkag+hiDHp6Fnx4Oy0sbgu5UU8xkpVRWdICJGsr+hcHPfyh3ixmamqlLNE4+Tsmg5Bu2rITQ5hZBmABAr3EO5TTkUgxc8qfq+Xu7q/RftKprK5p0i24tI2vOGdUBWcEcpFfWYOVJZ52nT0DyEcrH9GaKHoPRaTnHE5xYqsz2Ce7mUjkSVC6LfD3eI63rCOH/mrMFBw9bHH6J81SkNbYUrm209Z7SsEIkRctrde9tTmYZLfJ4lzhrcGpHU0v4B72LW0UinbUhidHqpny+CXcp/+o31rD837oTl2px/0hhxV?cssminify=yes' type='text/css' media='all' />
<style id='wp-block-library-inline-css'>
.has-text-align-justify {
	text-align:justify;
}
</style>
<style id='wpcom-admin-bar-inline-css'>

			.admin-bar {
				position: inherit !important;
				top: auto !important;
			}
			.admin-bar .goog-te-banner-frame {
				top: 32px !important
			}
			@media screen and (max-width: 782px) {
				.admin-bar .goog-te-banner-frame {
					top: 46px !important;
				}
			}
			@media screen and (max-width: 480px) {
				.admin-bar .goog-te-banner-frame {
					position: absolute;
				}
			}
		
</style>
<style id='global-styles-inline-css'>
:root{--wp--preset--color--primary: #1279BE;--wp--preset--color--secondary: #FFB302;--wp--preset--color--foreground: #303030;--wp--preset--color--background: #FFFFFF;--wp--preset--color--tertiary: #C5C5C5;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 17.3914px;--wp--preset--font-size--normal: 23px;--wp--preset--font-size--large: 26.45px;--wp--preset--font-size--huge: 30.4174px;}:root{--wp--style--color--link: var(--wp--preset--color--primary);}.has-primary-color{color: #1279BE;}.has-primary-background-color{background-color: #1279BE;}.has-secondary-color{color: #FFB302;}.has-secondary-background-color{background-color: #FFB302;}.has-foreground-color{color: #303030;}.has-foreground-background-color{background-color: #303030;}.has-background-color{color: #FFFFFF;}.has-background-background-color{background-color: #FFFFFF;}.has-tertiary-color{color: #C5C5C5;}.has-tertiary-background-color{background-color: #C5C5C5;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);}.has-cool-to-warm-spectrum-gradient-background{background: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);}.has-blush-light-purple-gradient-background{background: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);}.has-blush-bordeaux-gradient-background{background: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);}.has-luminous-dusk-gradient-background{background: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);}.has-pale-ocean-gradient-background{background: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);}.has-electric-grass-gradient-background{background: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);}.has-midnight-gradient-background{background: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);}.has-small-font-size{font-size: 17.3914px;}.has-normal-font-size{font-size: 23px;}.has-large-font-size{font-size: 26.45px;}.has-huge-font-size{font-size: 30.4174px;}a{color:var(--wp--style--color--link, #00e);}
</style>
<link rel='stylesheet' id='all-css-2-1' href='https://s0.wp.com/wp-content/mu-plugins/comment-likes/css/comment-likes.css?m=1407378799h&cssminify=yes' type='text/css' media='all' />
<link rel='stylesheet' id='print-css-3-1' href='https://s0.wp.com/wp-content/themes/pub/varia/print.css?m=1571655471h&cssminify=yes' type='text/css' media='print' />
<link rel='stylesheet' id='all-css-4-1' href='https://s0.wp.com/_static/??-eJx9jUsOwjAMRC+EsVoqWCHOkqZuGkjiKHEacXtasSkfdeeR35vBGkFzEAqCMpGnjLH0ONFMCbM8HR11zgf8j80qWYU26DcKNWr2P4IvEF0xNmSsdjAkGaksX35YAqcqCvnolCyl/xc3BYYYHGsllsNHgNEpm/bUwOuCGrwN0KsEc7tHJ+odm+U0uFCbuCcJZ0gUOQmMnPx3XtWbvzbnpmu7S3tq7i9qro7m?cssminify=yes' type='text/css' media='all' />
<link crossorigin="anonymous" rel='stylesheet' id='hever-fonts-css'  href='https://fonts.googleapis.com/css?family=PT+Sans%3A400%2C400i%2C700%2C700i&#038;subset=latin%2Clatin-ext&#038;display=swap' media='all' />
<link rel='stylesheet' id='all-css-6-1' href='https://s0.wp.com/_static/??/wp-content/themes/pub/hever/style.css,/wp-content/mu-plugins/admin-bar/masterbar-overrides/masterbar.css?m=1614247231j&cssminify=yes' type='text/css' media='all' />
<style id='jetpack-global-styles-frontend-style-inline-css'>
:root { --font-headings: unset; --font-base: unset; --font-headings-default: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif; --font-base-default: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;}
</style>
<link rel='stylesheet' id='all-css-8-1' href='https://s0.wp.com/_static/??-eJxti0EKgCAQAD+ULUaJl+gtJqbG6opr9P3o0CHqNAzMwFmEpdxcbpAOUfDwMTMU4iY2NLECB1Nj9g97y9zB/8Vko0GB5Oktn6kFlxxDGMEjrQbvYEmzVHIclNZy2i9lFDfR?cssminify=yes' type='text/css' media='all' />
<script id='wpcom-actionbar-placeholder-js-extra'>
var actionbardata = {"siteID":"190132804","siteName":"Site Title","siteURL":"http:\/\/monikamobiles.wordpress.com","icon":"<img alt='' src='https:\/\/s0.wp.com\/i\/logo\/wpcom-gray-white.png' class='avatar avatar-50' height='50' width='50' \/>","canManageOptions":"1","canCustomizeSite":"1","isFollowing":"1","themeSlug":"pub\/hever","signupURL":"https:\/\/wordpress.com\/start\/","loginURL":"https:\/\/wordpress.com\/log-in?redirect_to=https%3A%2F%2Fmonikamobiles.wordpress.com%2F&signup_flow=account","themeURL":"https:\/\/wordpress.com\/theme\/hever\/","xhrURL":"https:\/\/monikamobiles.wordpress.com\/wp-admin\/admin-ajax.php","nonce":"e633969f1b","isSingular":"1","isFolded":"","isLoggedIn":"1","isMobile":"","subscribeNonce":"<input type=\"hidden\" id=\"_wpnonce\" name=\"_wpnonce\" value=\"f88ae57ac0\" \/>","referer":"https:\/\/monikamobiles.wordpress.com\/","canFollow":"1","feedID":"114803376","statusMessage":"","customizeLink":"https:\/\/monikamobiles.wordpress.com\/wp-admin\/customize.php?url=https%3A%2F%2Fmonikamobiles.wordpress.com%2F","postID":"5","shortlink":"https:\/\/wp.me\/PcRMe8-5","canEditPost":"1","editLink":"https:\/\/wordpress.com\/page\/monikamobiles.wordpress.com\/5","statsLink":"https:\/\/wordpress.com\/stats\/post\/5\/monikamobiles.wordpress.com","i18n":{"view":"View site","follow":"Follow","following":"Following","edit":"Edit","login":"Log in","signup":"Sign up","customize":"Customize","report":"Report this content","themeInfo":"Get help setting up your theme","shortlink":"Copy shortlink","copied":"Copied","followedText":"New posts from this site will now appear in your <a href=\"https:\/\/wordpress.com\/read\">Reader<\/a>","foldBar":"Collapse this bar","unfoldBar":"Expand this bar","editSubs":"Manage subscriptions","viewReader":"View site in Reader","viewReadPost":"View post in Reader","subscribe":"Sign me up","enterEmail":"Enter your email address","followers":"","alreadyUser":"Already have a WordPress.com account? <a href=\"https:\/\/wordpress.com\/log-in?redirect_to=https%3A%2F%2Fmonikamobiles.wordpress.com%2F&signup_flow=account\">Log in now.<\/a>","stats":"Stats"}};
</script>
<script type='text/javascript' src='https://s0.wp.com/_static/??-eJyNjtEKwjAMRX/ItqzCxAfxW7aZlZQ2qU3D8O/twx5EhgiBS7iHy3FbMUhL0geIi/2eCvW1h81INsrJ/YJMxlCnBp/wwtSAmstqStKAJE50lqViacj9Wzkl3r7xPl1YWgaRKcBBm3nGBEYFageodauVjwyl/GFud+qeb8M4+PPFX0cf38HWZd0='></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://monikamobiles.wordpress.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://s0.wp.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress.com" />
<link rel="canonical" href="https://monikamobiles.wordpress.com/" />
<link rel='shortlink' href='https://wp.me/PcRMe8-5' />
<link rel="alternate" type="application/json+oembed" href="https://public-api.wordpress.com/oembed/?format=json&amp;url=https%3A%2F%2Fmonikamobiles.wordpress.com%2F&amp;for=wpcom-auto-discovery" /><link rel="alternate" type="application/xml+oembed" href="https://public-api.wordpress.com/oembed/?format=xml&amp;url=https%3A%2F%2Fmonikamobiles.wordpress.com%2F&amp;for=wpcom-auto-discovery" />
<!-- Jetpack Open Graph Tags -->
<meta property="og:type" content="website" />
<meta property="og:title" content="Site Title" />
<meta property="og:url" content="https://monikamobiles.wordpress.com/" />
<meta property="og:site_name" content="Site Title" />
<meta property="og:image" content="https://monikamobiles.files.wordpress.com/2021/03/galaxy-note-3.jpg" />
<meta property="og:locale" content="en_US" />
<meta name="twitter:site" content="@wordpressdotcom" />
<meta name="twitter:text:title" content="Home" />
<meta name="twitter:image" content="https://monikamobiles.files.wordpress.com/2021/03/galaxy-s4.jpg?w=144" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="Visit the post for more." />
<meta property="fb:app_id" content="249643311490" />
<meta property="article:publisher" content="https://www.facebook.com/WordPresscom" />

<!-- End Jetpack Open Graph Tags -->
<link rel="shortcut icon" type="image/x-icon" href="https://s0.wp.com/i/favicon.ico" sizes="16x16 24x24 32x32 48x48" />
<link rel="icon" type="image/x-icon" href="https://s0.wp.com/i/favicon.ico" sizes="16x16 24x24 32x32 48x48" />
<link rel="apple-touch-icon" href="https://s0.wp.com/i/webclip.png" />
<link rel="search" type="application/opensearchdescription+xml" href="https://monikamobiles.wordpress.com/osd.xml" title="Site Title" />
<link rel="search" type="application/opensearchdescription+xml" href="https://s1.wp.com/opensearch.xml" title="WordPress.com" />
<meta name="application-name" content="Site Title" /><meta name="msapplication-window" content="width=device-width;height=device-height" /><meta name="msapplication-tooltip" content="Author posts, manage comments, and manage Site Title." /><meta name="msapplication-task" content="name=Edit page;action-uri=https://wordpress.com/page/monikamobiles.wordpress.com/5;icon-uri=https://s0.wp.com/i/icons/page.ico" /><meta name="msapplication-task" content="name=Write a post;action-uri=https://wordpress.com/post/monikamobiles.wordpress.com;icon-uri=https://s0.wp.com/i/icons/post.ico" /><meta name="msapplication-task" content="name=Moderate comments;action-uri=https://monikamobiles.wordpress.com/wp-admin/edit-comments.php?comment_status=moderated;icon-uri=https://s0.wp.com/i/icons/comment.ico" /><meta name="msapplication-task" content="name=Upload new media;action-uri=https://monikamobiles.wordpress.com/wp-admin/media-new.php;icon-uri=https://s0.wp.com/i/icons/media.ico" /><meta name="msapplication-task" content="name=Blog stats;action-uri=https://monikamobiles.wordpress.com/wp-admin/index.php?page=stats;icon-uri=https://s0.wp.com/i/icons/stats.ico" /><style type="text/css" media="print">#wpadminbar { display:none; }</style>
	<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>
	</head>

<body class="home page-template-default page page-id-5 logged-in admin-bar no-customize-support wp-embed-responsive customizer-styles-applied singular image-filters-enabled hide-homepage-title mobile-nav-side highlander-enabled highlander-light">

		<div id="wpadminbar" class="nojq nojs ltr">
							<a class="screen-reader-shortcut" href="#wp-toolbar" tabindex="1">Skip to toolbar</a>
						<div class="quicklinks" id="wp-toolbar" role="navigation" aria-label="Toolbar" tabindex="0">
						<ul id="wp-admin-bar-root-default" class="ab-top-menu">
			
		<li id="wp-admin-bar-blog" class="my-sites mb-trackable"><a class="ab-item"  href="https://wordpress.com/sites/monikamobiles.wordpress.com">My Site</a>		</li>
		<li id="wp-admin-bar-jumptotop-button-menu"><a class="ab-item"  href="#"><div id="jumptotop"><span class="noticon noticon-top"></span></div></a>		</li>
		<li id="wp-admin-bar-newdash" class="mb-trackable"><a class="ab-item"  href="https://wordpress.com/read">Reader</a>		</li>		</ul>
			<ul id="wp-admin-bar-top-secondary" class="ab-top-secondary ab-top-menu">
			
		<li id="wp-admin-bar-notes" class="menupop">		<div class="ab-item ab-empty-item" ><span id="wpnt-notes-unread-count" class="wpnt-loading wpn-read"></span><span class="noticon noticon-bell"></span><span class="ab-text">Notifications</span></div><div id="wpnt-notes-panel2" style="display:none" lang="en" dir="ltr"><div class="wpnt-notes-panel-header"><span class="wpnt-notes-header"></span><span class="wpnt-notes-panel-link"></span></div></div>		</li>
		<li id="wp-admin-bar-my-account" class="with-avatar mb-trackable"><a class="ab-item"  href="https://wordpress.com/me/"><img alt='' src='https://1.gravatar.com/avatar/46119ddc1f28a9aff051d4f9e37e5006?s=32&#038;d=mm&#038;r=G' class='avatar avatar-32' height='32' width='32' /><span class="ab-text">Me</span></a>		</li>
		<li id="wp-admin-bar-ab-new-post" class="mb-trackable"><a class="ab-item"  href="https://wordpress.com/post/monikamobiles.wordpress.com"><span>Write</span></a>		</li>		</ul>
				</div>
							<a class="screen-reader-shortcut" href="https://monikamobiles.wordpress.com/wp-login.php?action=logout&#038;_wpnonce=465d4b1b13">Log Out</a>
					</div>

	
<script type="text/javascript">
/* <![CDATA[ */
var clickDebugLink;

jQuery(document).ready( function($) {
	var single = false, w = 1000,
		supe = false;

	$(document.body).load(function(){ $('#wpadminbar img.grav-hashed').removeClass('grav-hashed'); }); // hack to hide the gravatar hovercard

	if ( single && supe )
		w = 1385;
	else if ( supe )
		w = 1200;

	// debug bar extra
	clickDebugLink = function( parent_id, obj ) {

		$('#'+parent_id).children('div').hide();

		document.getElementById( obj.href.substr( obj.href.indexOf( '#' ) + 1 ) ).style.display = 'block';
		$( obj.href.substr( obj.href.indexOf( '#' ) ) ).show()

		$(obj).parent().addClass('current').siblings('li').removeClass('current');

		return false;
	};

	$( '#wpadminbar #wp-admin-bar-shortlink' ).click( function() {
		$( '#adminbar-shortlink-input' ).select();
	});

	// skip tap-to-hover on site switcher for mobile
	if ( 'ontouchstart' in window ) {
		$('#wp-admin-bar-switch-site').on( 'touchstart', function( event ) {
			if ( $( window ).width() > 782 ) {
				return;
			}
			event.stopPropagation();
			$( event.target ).first( 'a' ).click();
		});
	}

});
/* ]]> */
</script>
	<div class="wpcom-bubble action-bubble">
		<div class="bubble-txt"></div>
	</div>
	<script type="text/javascript">function hideBubble() { jQuery('body').append( jQuery( 'div.wpcom-bubble' ).removeClass( 'fadein' ) ).off( 'click.bubble touchstart.bubble' ); jQuery(document).off( 'scroll.bubble' ); };</script>
		<script type="text/javascript">
	jQuery( '#wp-admin-bar-jumptotop-button-menu a' ).click( function( e ) {
		e.preventDefault();
		jQuery( 'html, body' ).animate( { scrollTop: 0 }, 'fast' );
	} );
	function hideShowTbJumpToTop() {
		var total_width = 0;
		// Calculate total width taken by items minus our button to see if it'll
		// overlap with other toolbar menus.
		jQuery( '#wp-admin-bar-root-default > li' ).each( function() {
			var self = jQuery( this );
			if ( 'wp-admin-bar-jumptotop-button-menu' != self.attr( 'id' ) )
				total_width += self.width();
		});
		if ( jQuery( '#wp-admin-bar-jumptotop-button-menu' ).position()['left'] - total_width < 10 ) {
			jQuery( '#jumptotop' ).animate( { 'top': '-50px' }, 'fast' );
		} else if (  jQuery( window ).scrollTop() >= 350 && parseInt( jQuery( '#jumptotop' ).css( 'top' ) ) < 0 ) {
			if ( jQuery( '#wp-admin-bar-jumptotop-button-menu' ).position()['left'] - total_width < 10 )
			   return;
			jQuery( '#jumptotop' ).animate( { 'top': 0 }, 'fast' );
		} else if (  jQuery( window ).scrollTop() < 1 && parseInt( jQuery( '#jumptotop' ).css( 'top' ) ) >= 0 ) {
			jQuery( '#jumptotop' ).animate( { 'top': '-50px' }, 'fast' );
		}
	}
	// handle on page load if auto scrolling to a position
	hideShowTbJumpToTop();
	// bind to scrolll event
	var jumpToTopTimer = null;
	jQuery( window ).scroll( function() {
		clearTimeout( jumpToTopTimer );
		jumpToTopTimer = setTimeout( jumpToTopRefresh, 150 );
	} );
	var jumpToTopRefresh = function() {
		hideShowTbJumpToTop();
	};
	</script>
	
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	
<header id="masthead" class="site-header responsive-max-width has-title-and-tagline has-menu" role="banner">
	

			<p class="site-title"><a href="https://monikamobiles.wordpress.com/" rel="home">Site Title</a></p>
	
		<nav id="site-navigation" class="main-navigation" aria-label="Main Navigation">

		<input type="checkbox" role="button" aria-haspopup="true" id="toggle" class="hide-visually">
		<label for="toggle" id="toggle-menu" class="button">
			Menu			<span class="dropdown-icon open">+</span>
			<span class="dropdown-icon close">&times;</span>
			<span class="hide-visually expanded-text">expanded</span>
			<span class="hide-visually collapsed-text">collapsed</span>
		</label>

		<div class="main-menu-container"><ul id="menu-primary-1" class="main-menu" aria-label="submenu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5 current_page_item menu-item-19"><a href="https://monikamobiles.wordpress.com/" aria-current="page">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="https://monikamobiles.wordpress.com/blog/">Blog</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="https://monikamobiles.wordpress.com/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="https://monikamobiles.wordpress.com/contact/">Contact</a></li>
</ul></div>	</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

			
<article id="post-5" class="post-5 page type-page status-publish hentry entry">

	<header class="entry-header responsive-max-width">
		
<h1 class="entry-title">Home</h1>
	</header>

	
	<div class="entry-content">
		
<div class="wp-block-jetpack-layout-grid alignfull column1-desktop-grid__span-12 column1-desktop-grid__row-1 column1-tablet-grid__span-8 column1-tablet-grid__row-1 column1-mobile-grid__span-4 column1-mobile-grid__row-1">
<div class="wp-block-jetpack-layout-grid-column wp-block-jetpack-layout-grid__padding-none">
<div class="wp-block-columns">
<div class="wp-block-column" style="flex-basis:66.66%;">
<div class="wp-block-columns">
<div class="wp-block-column">
<div class="wp-block-jetpack-slideshow aligncenter" data-effect="slide"><div class="wp-block-jetpack-slideshow_container swiper-container"><ul class="wp-block-jetpack-slideshow_swiper-wrapper swiper-wrapper"><li class="wp-block-jetpack-slideshow_slide swiper-slide"><figure><img alt="" class="wp-block-jetpack-slideshow_image wp-image-36" data-id="36" src="https://monikamobiles.files.wordpress.com/2021/03/galaxy-note-3.jpg" /></figure></li><li class="wp-block-jetpack-slideshow_slide swiper-slide"><figure><img alt="" class="wp-block-jetpack-slideshow_image wp-image-37" data-id="37" src="https://monikamobiles.files.wordpress.com/2021/03/galaxy-s4.jpg" /></figure></li><li class="wp-block-jetpack-slideshow_slide swiper-slide"><figure><img alt="" class="wp-block-jetpack-slideshow_image wp-image-35" data-id="35" src="https://monikamobiles.files.wordpress.com/2021/03/galaxy-note-4.jpg" /></figure></li></ul><a class="wp-block-jetpack-slideshow_button-prev swiper-button-prev swiper-button-white" role="button"></a><a class="wp-block-jetpack-slideshow_button-next swiper-button-next swiper-button-white" role="button"></a><a aria-label="Pause Slideshow" class="wp-block-jetpack-slideshow_button-pause" role="button"></a><div class="wp-block-jetpack-slideshow_pagination swiper-pagination swiper-pagination-white"></div></div></div>
</div>
</div>
</div>



<div class="wp-block-column" style="flex-basis:33.33%;">
<ul><li></li></ul>
</div>
</div>
</div>
</div>



<p></p>
	</div><!-- .entry-content -->

			<footer class="entry-footer responsive-max-width">
			<span class="edit-link"><a class="post-edit-link" href="https://wordpress.com/page/monikamobiles.wordpress.com/5">Edit <span class="screen-reader-text">Home</span></a></span>		</footer><!-- .entry-footer -->
	</article><!-- #post-5 -->

		</main><!-- #main -->
	</section><!-- #primary -->


	</div><!-- #content -->

	
	<footer id="colophon" class="site-footer responsive-max-width">
			
	
		<div class="site-info">
		<a class="site-name" href="https://monikamobiles.wordpress.com/" rel="home">Site Title</a><span class="comma">,</span>
<a href="https://wordpress.com/?ref=footer_website" rel="nofollow">Create a free website or blog at WordPress.com.</a>	</div><!-- .site-info -->
	</footer><!-- #colophon -->

</div><!-- #page -->

<!--  -->
	<script type="text/javascript">
	/* <![CDATA[ */
		jQuery(document).ready( function($) {
			function doFollowingHover() {
				$('#wp-admin-bar-follow > a').unbind( '.unfollow' );

				$('#wp-admin-bar-follow > a').bind( 'mouseover.unfollow', function() {

					$(this).html( "Unfollow" ).parent( 'li' ).addClass( 'unfollow' );
				});
				$('#wp-admin-bar-follow > a').bind( 'mouseout.unfollow', function() {
					$(this).html( "Following" ).parent( 'li' ).removeClass( 'unfollow' );
				});
			}
							doFollowingHover();
			
			$('#wp-admin-bar-follow > a').click( function( e ) {
				$('#wp-admin-bar-follow > a').unbind( '.unfollow' );

				e.preventDefault();

				var link = $( this ), li = $( '#wp-admin-bar-follow' ), timeout = 0;

				if ( li.hasClass( 'subscribed' ) ) {
					li.removeClass( 'subscribed' ).removeClass( 'unfollow' );
					link.html( "Follow" );

					$('body').append( $( 'div.wpcom-bubble' ).removeClass( 'fadein' ) ).off( 'click.bubble' );

					var action = 'ab_unsubscribe_from_blog';
				} else {
					li.addClass( 'subscribed' ).removeClass( 'unfollow' );
					link.html( "Following" );

						var left = 131 - link.width();
						li.append( $( 'div.wpcom-bubble' ).css( { left: '-' + left + 'px' } ) );
						$( 'div.bubble-txt', 'div.wpcom-bubble' ).html( "New posts from this blog will now appear in \u003Ca target=\u0022_blank\u0022 href=\u0022http:\/\/wordpress.com\/\u0022\u003Eyour reader\u003C\/a\u003E. You can manage email alerts from your \u003Ca target=\u0022_blank\u0022 href=\u0022http:\/\/wordpress.com\/following\/edit\/\u0022\u003Esubscriptions page\u003C\/a\u003E." );

						$( 'div.wpcom-bubble.action-bubble' ).addClass( 'fadein' );

						setTimeout( function() {
							$('body').on( 'click.bubble touchstart.bubble', function(e) {
								if ( !$(e.target).hasClass('wpcom-bubble') && !$(e.target).parents( 'div.wpcom-bubble' ).length )
									hideBubble();
							});
							setTimeout( hideBubble, 15000 );
						}, 500 );

					var action = 'ab_subscribe_to_blog';
					$('#wp-admin-bar-follow > a').bind( 'mouseout.shift', function() {
						doFollowingHover();
						$(this).unbind( '.shift' );
					});
				}

				var nonce = link.attr( 'href' ).split( '_wpnonce=' );
				nonce = nonce[1];

				$.post( "https:\/\/monikamobiles.wordpress.com\/wp-admin\/admin-ajax.php", {
					'action': action,
					'_wpnonce': nonce,
					'source': 'admin_bar',
					'blog_id': 190132804				});
			});
		});
	/* ]]> */
	</script>
<script src='//0.gravatar.com/js/gprofiles.js?ver=202109y' id='grofiles-cards-js'></script>
<script id='wpgroho-js-extra'>
var WPGroHo = {"my_hash":"46119ddc1f28a9aff051d4f9e37e5006"};
</script>
<script type='text/javascript' src='https://s0.wp.com/wp-content/mu-plugins/gravatar-hovercards/wpgroho.js?m=1610363240h'></script>

	<script>
		// Initialize and attach hovercards to all gravatars
		( function() {
			function init() {
				if ( typeof Gravatar === 'undefined' ) {
					return;
				}

				if ( typeof Gravatar.init !== 'function' ) {
					return;
				}

				Gravatar.profile_cb = function ( hash, id ) {
					WPGroHo.syncProfileData( hash, id );
				};

				Gravatar.my_hash = WPGroHo.my_hash;
				Gravatar.init( 'body', '#wp-admin-bar-my-account' );
			}

			if ( document.readyState !== 'loading' ) {
				init();
			} else {
				document.addEventListener( 'DOMContentLoaded', init );
			}
		} )();
	</script>

		<div style="display:none">
	<div class="grofile-hash-map-46119ddc1f28a9aff051d4f9e37e5006">
	</div>
	</div>
<div id="report-form-window" style="display:none;"></div>
<script>
window.addEventListener( "load", function( event ) {
	var link = document.createElement( "link" );
	link.href = "https://s0.wp.com/wp-content/mu-plugins/actionbar/actionbar.css?v=20201002";
	link.type = "text/css";
	link.rel = "stylesheet";
	document.head.appendChild( link );

	var script = document.createElement( "script" );
	script.src = "https://s0.wp.com/wp-content/mu-plugins/actionbar/actionbar.js?v=20201002";
	script.defer = true;
	document.body.appendChild( script );
} );
</script>

	<link rel='stylesheet' id='all-css-0-2' href='https://s0.wp.com/_static/??/wp-content/mu-plugins/jetpack/_inc/blocks/slideshow/view.css,/wp-content/plugins/gutenberg-blocks/jetpack-layout-grid/blocks/front.css?m=1612173294j&cssminify=yes' type='text/css' media='all' />
<script id='thickbox-js-extra'>
var thickboxL10n = {"next":"Next >","prev":"< Prev","image":"Image","of":"of","close":"Close","noiframes":"This feature requires inline frames. You have iframes disabled or your browser does not support them.","loadingAnimation":"https:\/\/s0.wp.com\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
</script>
<script id='comment-like-js-extra'>
var comment_like_text = {"loading":"Loading..."};
</script>
<script id='notes-rest-common-js-extra'>
var wpNotesArgs = {"cacheBuster":"@automattic\/jetpack-blocks@13.1.0-10451-g9f7e375b88","iframeUrl":"https:\/\/widgets.wp.com\/notifications\/","iframeAppend":"2","iframeScroll":"no","wide":"1"};
</script>
<script id='tos-report-form-js-extra'>
var wpcom_tos_report_form = {"ajaxurl":"\/wp-admin\/admin-ajax.php","isLoggedoutUser":"","post_ID":"5","current_url":"https:\/\/monikamobiles.wordpress.com","report_this_content":"Report this content"};
</script>
<script type='text/javascript' src='https://s0.wp.com/_static/??-eJydktluwyAQRX+omDhVq7xU/RaWiT02MIjNyd8XUiVNIyddXhBw72XgMHzxTJFL4BKfItdQUIE/dFN84lVCp0zWEJuWRlSzpMNlsmYaqUDA03lsip1Ft+YSugpMinBtOF/DZuZNHtBd+aquyLKv3P1M9dlW3eD8Wcyg5HFBD38Jfdu4DaYRbLX5LHkRAUUL+IBWhCNzouAgEtKjdy2oB0iRQ64qzQjMiIUnsN6IBDf7awCz0xCiogD3EEvR/sjBGuEq2xyTUOMjJo7aVU4jazjIsbL90X/5osfmRJEF8BQS21Owt+tf9YQVMUFopVKor41rGDTGxAs4Ta2HmCdz3KMxa1TOBYZclxLCwBpfXvpNt+m2XGY0uvY3zZFjxX/4Vx77nbvE3+1b/9o/v+z6za6fPgAafk9b'></script>
<script type='text/javascript'>
( 'fetch' in window ) || document.write( '<script src="https://s0.wp.com/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?m=1612197847h&#038;ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="https://s0.wp.com/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?m=1540208548h&#038;ver=3.42.0"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script src="https://s0.wp.com/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?m=1612197847h&#038;ver=3.42.0"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script src="https://s0.wp.com/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?m=1585663916h&#038;ver=3.6.4"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="https://s0.wp.com/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?m=1550600082h&#038;ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="https://s0.wp.com/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?m=1540208548h&#038;ver=2.0.2"></scr' + 'ipt>' );
( "objectFit" in document.documentElement.style ) || document.write( '<script src="https://s0.wp.com/wp-content/plugins/gutenberg-core/v10.0.2/vendor/object-fit-polyfill.min.f68d8b8b.js?m=1611569426h&#038;ver=2.3.0"></scr' + 'ipt>' );
</script>
<script type='text/javascript'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] }, 'default' );
</script>
<script id='lodash-js-translations'>
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script src='https://s0.wp.com/wp-content/plugins/gutenberg-core/v10.0.2/vendor/lodash.ec373016.js?m=1599596311h&#038;ver=4.17.19' id='lodash-js'></script>
<script id='lodash-js-after'>
window.lodash = _.noConflict();
</script>
<script id='jetpack-block-slideshow-js-extra'>
var Jetpack_Block_Assets_Base_Url = {"url":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/jetpack\/_inc\/blocks\/"};
</script>
<script type='text/javascript' src='https://s0.wp.com/_static/??-eJyVzMkOwiAUheEXEm7R2ujC+CgNww2FMoWh6NvLxp0blyd/zgc9ERlDxVAhuaZNKKDbmAKzHiUjHGyiEz2DaMYpUNGTjFy9wQSFL2rLCf41sEiekGzVu9+Kb+QLWayJyx1WEyQIF+VeoDijsGyxw2Gwj/PTP9jC5styvd1n+wEF6EwA'></script>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	<script type="text/javascript">
// <![CDATA[
(function() {
try{
  if ( window.external &&'msIsSiteMode' in window.external) {
    if (window.external.msIsSiteMode()) {
      var jl = document.createElement('script');
      jl.type='text/javascript';
      jl.async=true;
      jl.src='/wp-content/plugins/ie-sitemode/custom-jumplist.php';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(jl, s);
    }
  }
}catch(e){}
})();
// ]]>
</script><script src="//stats.wp.com/w.js?61" defer></script> <script type="text/javascript">
_tkq = window._tkq || [];
_stq = window._stq || [];
_tkq.push(['identifyUser', 202609003, 'sivakumar2001']);
_tkq.push(['storeContext', {'blog_id':'190132804','blog_tz':'5','user_lang':'en','blog_lang':'en'}]);
_stq.push(['view', {'blog':'190132804','v':'wpcom','tz':'5','user':'1','user_id':'202609003','post':'5','subd':'monikamobiles'}]);
_stq.push(['extra', {'crypt':'UE40eW5QN0p8M2Y/RE1zNDZ8S252Wis9XUQyb3YrcUVIU2R0VH5TdVc3aWJOWS5HUTZSRHNZdTIzLmN+VUZ8MnpYNlVPT3FVV3otTDNqVE51UlpOZWpDd2xFWHpbbGgxRGx3aiZDWF9oSmJhUUJJeVFbVSUvJmI4VFpbTnFEZD95T1dWM3xqMEtnTUVQWnFPWDEzMjVKS0VbVDViU2hPREkxMUw3bGZMRklOWiZFV3l1LzF+MC9uSXptTHZ8WFhKQ1BUTUVERDJ5eDYrNVU1RVoxb0UxZVdUaWNoOEZ3WktnLlRWNERvZ1gxbFc/QXBHbGJx'}]);
	</script>
<noscript><img src="https://pixel.wp.com/b.gif?v=noscript" style="height:1px;width:1px;overflow:hidden;position:absolute;bottom:1px;" alt="" /></noscript>
<script>
if ( 'object' === typeof wpcom_mobile_user_agent_info ) {

	wpcom_mobile_user_agent_info.init();
	var mobileStatsQueryString = "";
	
	if( false !== wpcom_mobile_user_agent_info.matchedPlatformName )
		mobileStatsQueryString += "&x_" + 'mobile_platforms' + '=' + wpcom_mobile_user_agent_info.matchedPlatformName;
	
	if( false !== wpcom_mobile_user_agent_info.matchedUserAgentName )
		mobileStatsQueryString += "&x_" + 'mobile_devices' + '=' + wpcom_mobile_user_agent_info.matchedUserAgentName;
	
	if( wpcom_mobile_user_agent_info.isIPad() )
		mobileStatsQueryString += "&x_" + 'ipad_views' + '=' + 'views';

	if( "" != mobileStatsQueryString ) {
		new Image().src = document.location.protocol + '//pixel.wp.com/g.gif?v=wpcom-no-pv' + mobileStatsQueryString + '&baba=' + Math.random();
	}
	
}
</script>
</body>
</html>
